#Para instalar mais de uma Gem ao mesmo tempo usamos:
#Bundler

#Passo a passo:
#1. Criar uma pasta nova, ex: bundler
#2. instalar o bundler na nossa máquina
#para isso gem install bundler
#Dentro dessa pasta bundler vamos criar um arquivo chamado Gemfile e vamos colocar:
#source 'https://rubygems.org'
# gem 'os'
# gem (vamos pegar em um site)