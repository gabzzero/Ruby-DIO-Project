#exemplo 1 puts
#6.times {puts "Oi"}

#exemplo 1 print
#6.times {print "Oi "}


#exemplo 2 puts
#4.times do
#    puts "Oi"
#end

#exemplo 2 print
#4.times do
#    print "Oi "
#end

#exemplo 3 contador puts
20.times do |contador|
    puts "#{contador}"
end

#exemplo 3 contador print
20.times do |contador|
    print "#{contador}"
end


