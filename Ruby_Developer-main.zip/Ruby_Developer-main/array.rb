#vamos manipular arrays
#lista de livros
#criar um array vazio

#vamos adicionar um item nesse array nome.push('o que queremos colocar')

#vamos adicionar vários itens ao nosso array ao mesmo 
#tempo nome.push('o que queremos colocar', 'o que queremos colocar 2')

#organizando os novos dados da lista nome.insert(0, 'nome 1', 'nome 2')

#acessando os elementos do array nome[numero]

#acessando intervalos do array nome[1..4]

#recuperar o primeiro item nome.first

#recuperar o último elemento nome.last

#para saber quantidade de elementos de um array nome.count ou nome.length

#descubra se o array está vazio nome.empty?

#verifique se um nome está presente nesse array nome.include?('nome')

#para excluir elementos:
#elemento especifíco nome.delete_at(numero)

#exclua o último elemento nome.pop



#exclua o primeiro elemento nome.shift