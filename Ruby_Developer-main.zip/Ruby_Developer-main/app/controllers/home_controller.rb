class HomeController < ApplicationController
  def index
  end
end
