class Animal
    def dormir
       puts 'Zzzzzzzz'
    end

    def pular
        puts 'Tóin, tóin'
    end
end

animal = Animal.new
animal.pular
animal.dormir