#declara minha variavel
x = 20
  unless x > 15 # → a menos que x seja maior que 15
    puts "x é menor ou igual a 15"
  else
   puts "x é maior que 15"
  end