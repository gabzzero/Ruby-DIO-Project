#comparar um numero com uma condição
num = 1

#imprima todos os números, a partir de 1 e menores que 100
#execute esse código ENQUANTO (WHILE), num for MENOR que 100
while num < 100
    puts num
    #precisa pegar esse num que ele imprimiu e seguir para o próximo
    #utiliza o incremento (somar)
    num += 1
end