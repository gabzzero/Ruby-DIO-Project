require_relative './animal.rb'

require_relative './gato.rb'

