File.open('lista.txt', 'a') do |line|
    line.puts ('feijão')
    line.puts ('cebola')
end