print "Digite seu nome:  "
nome = gets.chomp
print "Digite seu sobrenome: "
sobrenome = gets.chomp
print "Digite sua idade: "
idade = gets.chomp
puts "Olá #{nome} #{sobrenome}! Seja bem vindo! Sua idade é #{idade}." 