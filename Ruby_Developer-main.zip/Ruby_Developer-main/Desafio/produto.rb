class Produto
    attr_accessor :nome, :preco
   end
   