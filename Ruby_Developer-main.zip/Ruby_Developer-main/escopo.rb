#escopo: define onde uma variável estará disponível dentro do seu programa.
#4 tipos em ruby
#1. locais
#2. globais
#3. classes
#4.instância

#LOCAIS: Podem ser acessadas apenas onde foram criada. 
#Forma: primeira letra minuscula ou sublinhada



#GLOBAIS: Pode ser acessada de qualquer lugar do programa. 
#Forma: use o prefixo $
# USO DESENCORAJADA

#CLASSE: Pode ser acessada de qualquer lugar da classe
#Forma: @@

#INSTÂNCIA: Semelhante a de classe
#Forma: @