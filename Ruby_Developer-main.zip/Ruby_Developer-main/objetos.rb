#definição: tudo que for material e que puder ser percebida, um objeto do mundo real
#ex: carro, casa, cachorro, avião, televisão, computador, livro
#Obs: todos os objetos apresentam características em comum:
#comportamentos e informações
#ex: cachorro
#ex: informações: são os atributos: tamanho, cor, raça, peso
#ex: comportamentos: são os métodos: latir, comer, morder
