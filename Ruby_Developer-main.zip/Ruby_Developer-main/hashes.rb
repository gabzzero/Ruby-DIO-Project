#manipulando hashes
#também é um tipo de lista, mas ela tem uma CHAVE: VALOR
#criando um hash vazio variavel = Hash.new

#podemos iniciar com pares CHAVE-VALOR variavel = {chave: 'valor', chave: 'valor'}

#adicione um nome item ao hash variavel[:nome inclusão] = "valor a ser add"

#para retornar todas as chaves de um hash nome.keys

#para retornar todos os valores de um hash nome.values

#para excluir um elemento nome.delete(:nome a ser exluido)

#descubra o tamanho do hash nome.size

#verifique se o hash está vazio nome.empty?


