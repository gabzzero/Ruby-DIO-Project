#definindo classe:
#A classe é a base para um objeto
#Exemplo: Eu quero construir um prédio (objeto), para isso eu preciso de uma planta (classe)
# Resumindo, a classe é uma descrição de como será esse objeto
#sozinha ela é apenas um desenho, mas junto com o objeto começamos a ver algo prático.
#veremos as propriedades desse objeto (métodos), tamanho, qts quartos, qts banheiros