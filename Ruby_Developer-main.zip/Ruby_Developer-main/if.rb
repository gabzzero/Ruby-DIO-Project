#analise um dia da semana
#SE esse dia da semana for domingo
#IMPRIMA que o nosso almoço será especial
dia = 'segunda'
if dia == 'domingo' #== é uma comparação
    almoco = 'especial'    
end
#imprime --> puts
puts "Hoje nosso almoço será #{almoco}"