#leia uma lista (array) de elemntos - linguagens de programação
#primeiro - criar a lista
linguagens = ['Ruby', 'Go', 'C++', 'python']
count = 1
#apareça na tela (puts) essa lista
#laço For
for linguagem in linguagens
    puts linguagem
    puts count
    count = count + 1
end