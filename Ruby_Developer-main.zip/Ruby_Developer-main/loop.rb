#criar um contador
#precisar de uma variável
count = 0

#loop de execução
loop do 
    puts count
    #condição --> SE (IF) contador não for igual a 150
    if count == 150
        break
        end
        #incremento --> somar 1
        count += 1
    end